package ��������;
import java.util.Random;
import java.util.Scanner;

public class St {	
	        public static void main(String[] args) {     	        
	        int right = 0;           
	        int wrong = 0;
	        Scanner sc=new Scanner(System.in);
	        
	        System.out.println("��������Ҫ���������");	  
	        int n = sc.nextInt();
	        for (int i = 0; i < n; i++) {
	            System.out.println("��"+(i+1)+"����,�����·�����𰸣�");	        
	        //�������������
	        Random r1 = new Random();
	        int x = r1.nextInt(10)+1;
	        Random r2 = new Random();
	        int y = r2.nextInt(10)+1;
	        //������������    + - * /
	        Random r3 = new Random();
	        int z = r3.nextInt(4);
	        char[] chs = {'+','-','*','/'};
	        String Operator = String.valueOf(chs[z]);	        
	        //������Ŀ
	        if(Operator.equals("+")){
	            System.out.println(x+"+"+y+"=");
	            boolean b = add(x,y);
	            if(b == true){
	                right++;System.out.println("��ϲ������!");
	            }else{
	                wrong++;System.out.println("����˱���ģ�");
	            }
	            System.out.println("��ȷ��Ϊ: "+(x+y));
	            
	        }else if(Operator.equals("-")){
	            System.out.println(x+"-"+y+"=");
	            boolean b =minus(x,y);
	            if(b == true){
	                right++;System.out.println("��ϲ������! ");
	            }else{
	                wrong++;System.out.println("����˱���ģ� ");
	            }
	            System.out.println("��ȷ��Ϊ: "+(x-y));
	            
	        }else if(Operator.equals("*")){
	            System.out.println(x+"��"+y+"=");
	            boolean b =times(x,y);
	            if(b == true){
	                right++;System.out.println("��ϲ������! ");
	            }else{
	                wrong++;System.out.println("����˱����! ");
	            }
	            System.out.println("��ȷ��Ϊ: "+(x*y));
	        }else{
	            System.out.println(x+"��"+y+"=");
	            boolean b =divide(x,y);
	            if(b == true){
	                right++;System.out.println("��ϲ������!");
	            }else{
	                wrong++;System.out.println("����˱����!");
	            }  
	            System.out.println("��ȷ��Ϊ: "+((float)x /(float) y));
	        }	     
	        System.out.println("-------------------------------");
	        }
	        System.out.println("��һ��������"+right+"����.");
	        System.out.println("��һ��������"+wrong+"����.");
	        System.out.println("�ܵ÷�"+((right*10)));
	        
	    }

	    private static boolean add(int x,int y) {
	        // TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        int num1 = sc.nextInt();
	        int result = x + y;
	        if(num1 == result){
	            return true;
	        }else{
	            return false;
	        }
	        
	    }
	    private static boolean minus(int x,int y) {
	        // TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        int num1 = sc.nextInt();
	        int result = x - y;
	        if(num1 == result){
	            return true;
	        }else{
	            return false;
	        }
	        
	    }
	    private static boolean times (int x,int y) {
	        // TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        int num1 = sc.nextInt();
	        int result = x * y;
	        if(num1 == result){
	            return true;
	        }else{
	            return false;
	        }
	    
	    }
	    private static boolean divide(int x,int y) {
	        // TODO Auto-generated method stub
	        Scanner sc = new Scanner(System.in);
	        float num1 = sc.nextFloat();
	        float result =(float)x /(float) y;
	        if(num1 == result){
	            return true;
	        }else{
	            return false;
	        }

	    }

	}
